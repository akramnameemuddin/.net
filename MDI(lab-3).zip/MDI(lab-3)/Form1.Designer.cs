﻿namespace MDI_lab_3_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tb1 = new TextBox();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn_clear = new Button();
            btn0 = new Button();
            btn_equal = new Button();
            btn_add = new Button();
            btn_sub = new Button();
            btn_mul = new Button();
            btn_div = new Button();
            SuspendLayout();
            // 
            // tb1
            // 
            tb1.Location = new Point(321, 54);
            tb1.Name = "tb1";
            tb1.Size = new Size(351, 31);
            tb1.TabIndex = 0;
            // 
            // btn1
            // 
            btn1.Location = new Point(321, 123);
            btn1.Name = "btn1";
            btn1.Size = new Size(71, 38);
            btn1.TabIndex = 1;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(418, 123);
            btn2.Name = "btn2";
            btn2.Size = new Size(71, 38);
            btn2.TabIndex = 2;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(510, 123);
            btn3.Name = "btn3";
            btn3.Size = new Size(71, 38);
            btn3.TabIndex = 3;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(321, 188);
            btn4.Name = "btn4";
            btn4.Size = new Size(71, 38);
            btn4.TabIndex = 4;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(418, 188);
            btn5.Name = "btn5";
            btn5.Size = new Size(71, 38);
            btn5.TabIndex = 5;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(510, 188);
            btn6.Name = "btn6";
            btn6.Size = new Size(71, 38);
            btn6.TabIndex = 6;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btn6_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(321, 249);
            btn7.Name = "btn7";
            btn7.Size = new Size(71, 38);
            btn7.TabIndex = 7;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(418, 249);
            btn8.Name = "btn8";
            btn8.Size = new Size(71, 38);
            btn8.TabIndex = 8;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(510, 249);
            btn9.Name = "btn9";
            btn9.Size = new Size(71, 38);
            btn9.TabIndex = 9;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btn_clear
            // 
            btn_clear.Location = new Point(321, 310);
            btn_clear.Name = "btn_clear";
            btn_clear.Size = new Size(71, 38);
            btn_clear.TabIndex = 10;
            btn_clear.Text = "AC";
            btn_clear.UseVisualStyleBackColor = true;
            btn_clear.Click += btn_clear_Click;
            // 
            // btn0
            // 
            btn0.Location = new Point(418, 310);
            btn0.Name = "btn0";
            btn0.Size = new Size(71, 38);
            btn0.TabIndex = 11;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += btn0_Click;
            // 
            // btn_equal
            // 
            btn_equal.Location = new Point(510, 310);
            btn_equal.Name = "btn_equal";
            btn_equal.Size = new Size(71, 38);
            btn_equal.TabIndex = 12;
            btn_equal.Text = "=";
            btn_equal.UseVisualStyleBackColor = true;
            btn_equal.Click += btn_equal_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(601, 123);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(71, 38);
            btn_add.TabIndex = 13;
            btn_add.Text = "+";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // btn_sub
            // 
            btn_sub.Location = new Point(601, 188);
            btn_sub.Name = "btn_sub";
            btn_sub.Size = new Size(71, 38);
            btn_sub.TabIndex = 14;
            btn_sub.Text = "-";
            btn_sub.UseVisualStyleBackColor = true;
            btn_sub.Click += btn_sub_Click;
            // 
            // btn_mul
            // 
            btn_mul.Location = new Point(601, 249);
            btn_mul.Name = "btn_mul";
            btn_mul.Size = new Size(71, 38);
            btn_mul.TabIndex = 15;
            btn_mul.Text = "*";
            btn_mul.UseVisualStyleBackColor = true;
            btn_mul.Click += btn_mul_Click;
            // 
            // btn_div
            // 
            btn_div.Location = new Point(601, 310);
            btn_div.Name = "btn_div";
            btn_div.Size = new Size(71, 38);
            btn_div.TabIndex = 16;
            btn_div.Text = "/";
            btn_div.UseVisualStyleBackColor = true;
            btn_div.Click += btn_div_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(980, 514);
            Controls.Add(btn_div);
            Controls.Add(btn_mul);
            Controls.Add(btn_sub);
            Controls.Add(btn_add);
            Controls.Add(btn_equal);
            Controls.Add(btn0);
            Controls.Add(btn_clear);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(tb1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tb1;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btn_clear;
        private Button btn0;
        private Button btn_equal;
        private Button btn_add;
        private Button btn_sub;
        private Button btn_mul;
        private Button btn_div;
    }
}
